window.onload = function () {
    document.querySelector('form').addEventListener('submit', addProduct);
}

function addProduct(e) {
    let productName = document.getElementById('product_name').value;
    let productPrice = document.getElementById('product_price').value;
    document.querySelector("#tbl_products>tbody").append(tr);
    let tr = document.createElement('tr');
    //for (let key in data) {
        let td = document.createElement('td');
        td.innerText = productPrice;
        tr.append(td);

    /*
    document.querySelector("#tbl_products>tbody").append(tr);
    let product = {name: productName, price: productPrice};
    fetch('product', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(product),
    })
        .then(response => response.json())
        .then(data => processData(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    e.target.reset();
    e.preventDefault();
}

function processData(data) {
    let tr = document.createElement('tr');
    for (let key in data) {
        let td = document.createElement('td');
        td.innerText = data[key];
        tr.append(td);
    }
    document.querySelector("#tbl_products>tbody").append(tr);*/
}



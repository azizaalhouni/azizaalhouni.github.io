package com.example.controller;


import com.example.dao.ProductDAO;
import com.example.model.Product;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/addtocart.jsp")
    public class AddToCart extends HttpServlet {

        private ProductDAO dao;
        Gson mapper = new Gson();


        @Override
        public void init() throws ServletException {
           // dao = ProductDAO.getDAO();
            dao = new ProductDAO();
        }


        @Override
        public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        }

        @Override
        public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

            HttpSession session=request.getSession();
            ///
            if (request.getParameter("JSESSIONID") != null) {
                Cookie userCookie = new Cookie("JSESSIONID", request.getParameter("JSESSIONID"));
                response.addCookie(userCookie);
            } else {
                String sessionId = session.getId();
                Cookie userCookie = new Cookie("JSESSIONID", sessionId);
                response.addCookie(userCookie);
            }

            List<Product> products= new ArrayList<Product>();

            StringBuilder sb = new StringBuilder();
            BufferedReader reader = request.getReader();
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            } finally {
                reader.close();
            }

            String json = sb.toString();
            Product product = mapper.fromJson(json, Product.class);
            Product buyProduct=dao.getProductById(product.getId());
            //createSession
            if (session.getAttribute("AddToCart") == null){
                products.add(buyProduct);
                session.setAttribute("AddToCart",products);
            }
            else{
                products= (List<Product>)session.getAttribute("AddToCart");
                products.add(buyProduct);
                session.setAttribute("AddToCart",products);
            }


            PrintWriter out = response.getWriter();
            out.print(mapper.toJson(buyProduct));
        }
    }

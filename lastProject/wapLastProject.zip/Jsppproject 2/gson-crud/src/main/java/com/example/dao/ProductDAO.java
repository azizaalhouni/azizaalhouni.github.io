package com.example.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.model.Product;


public class ProductDAO {
	
	Map<String, Product> productsDb = new HashMap<>();
	
	{
		productsDb.put("P122", new Product("P323", "iPohne", "549"));
		productsDb.put("P342", new Product("P234", "LG G6", "650"));
		productsDb.put("P343", new Product("P364", "S7 Edge", "750"));
	}
	
	public void addProduct(Product product){
		productsDb.put(product.getId(), product);
	}
	
	public void deleteProduct(String productId){
		productsDb.remove(productId);
	}
	
	public void updateProduct(Product product){
		productsDb.put(product.getId(), product);
	}
	
	public List<Product> getAllProducts(){
		return new ArrayList<>(productsDb.values());
	}
	
	public Product getProductById(String productId){
		return productsDb.get(productId);
	}

	public String genId() {
		return "P"+(int)Math.floor(Math.random()*1000);
	}
}

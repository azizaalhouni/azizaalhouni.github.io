package com.example.controller;

import com.example.dao.ProductDAO;
import com.example.dao.UserDAO;
import com.example.model.User;
import com.example.model.UserInfo;
import com.google.gson.Gson;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO dao;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        //initializing all the data value
        dao = new UserDAO();

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("users", dao.getAllUsers());
        RequestDispatcher view = req.getRequestDispatcher("signup.jsp");
        view.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {


        String userName = req.getParameter("user_name");
        String password = req.getParameter("pass");

        UserInfo username = UserDAO.userDb.get(userName);
        HttpSession session = req.getSession();
        // request.getServletContext().setAttribute("myAttr", val); for all application
        if (username == null) {

            session.setAttribute("user", new User(userName, password));
            resp.sendRedirect("welcome.jsp");
        } else {
            session.setAttribute("err_msg", "You already have an account");
            resp.sendRedirect("login");
        }
    }

    }




package com.example.dao;

import com.example.model.UserInfo;

import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDAO {

   public static Map <String, UserInfo> userDb = new HashMap<>();

     {
        userDb.put("user", new UserInfo("firstName","LastName","user","123"));
    }
    public void addUserInfo(UserInfo userInfo){
        userDb.put(userInfo.getUserName(), userInfo);
    }
    public List<UserInfo> getAllUsers(){
        return new ArrayList<>(userDb.values());
    }
    public String getUserName(){return getUserName();}

}



//AddTocart button
let cancelChecoutForm;
let addcart;
let checkoutButton;
window.onload = function () {
    addcart=document.getElementsByClassName("addToCart");
    cancelChecoutForm=document.getElementById("cancel_btn");
    checkoutButton=document.getElementById("checkout_btn");

    cancelChecoutForm.onclick=closeForm;
    for(const btns of addcart){
        btns.onclick=addToCart;
    }
}
function closeForm() {
    document.getElementById("myForm").style.display = "none";
}



function addToCart() {
    checkoutButton.disabled=false;
    let productId={id:this.id};
    console.log("product id"+ this.id);
    fetch('addtocart.jsp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(productId),
    })
        .then(response => response.json())
        .then(data => processData(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    //e.target.reset();
    //e.preventDefault();
}

function processData(data) {
    let cartCounter= document.getElementById("cartCounter");
console.log(data);
       cartCounter.textContent=parseInt(cartCounter.textContent)+1;
    let tr = document.createElement('tr');
    for (let key in data) {
        let td = document.createElement('td');
        td.innerText = data[key];
        tr.append(td);
    }
    document.querySelector("#cartlist>tbody").append(tr);
}




<!-- pop up -->
let openform= document.getElementById("openfrm");
openform.onclick=openForm;

function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

let obj={
    jeans:"$50",
    Shirt:"$60",
    shoes:"$100"
}

let price=0;

let cart= document.getElementById("cart");
let txtarea=document.getElementById("txtarea");
let pric= document.getElementById("price");
let addrt=document.getElementsByClassName("addcart");
addrt[0].onclick=getId;
let productName="";
console.log(addrt[0]);
function getId(){
     productName=this.id;
    console.log(this.id);
    for(const keys in obj){
        if(keys===this.id){
          price=obj[keys];
        }
    }
    pric.insertAdjacentHTML("afterEnd", "<br/>"+productName+":"+price);

}





/*
cart.onclick= getdata;

async function getdata() {
    let user = {name: 'John', surname: 'Smith'};
    let response = await fetch('http://localhost:8181/addtocart.jsp', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        //body: JSON.stringify(user)
    });
    let result = await response.json();
    txtarea.value=result;
    alert(result.message);
}
*/

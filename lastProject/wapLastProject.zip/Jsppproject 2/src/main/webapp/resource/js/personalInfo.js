window.onload = function(){
    document.getElementById("myInfo").onclick = getPersonalInfo;
}
//var firstname = data.user.firstName;
 function getPersonalInfo() {

     //const userName = `${user.userName}`;


     let user = {userName: userName, password: "123"};
     fetch(`login`,{
         method:'POST',
         headers:{"Content-Type": "application/json"},
         body: JSON.stringify(user)
     })
         .then(resp => resp.Json())
         .then(data =>processData(data));

 }
function processData(data) {
    let result = document.getElementById("myPersonal");
    result.innerText = data;
}
/*
    let response = await fetch('resource/test.text', {
        method: 'Post',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(user),

       // body: JSON.stringify(user)
    });
    let result = await response.json();
    document.getElementById("myPersonal").style.color = "red";
    //if (document.getElementById("myPersonal").innerText == null) {
        document.getElementById("myPersonal").innerText = `${result.firstName}` + `${result.lastName}`;*/
    //}
//else
  //  {
//document.getElementById("myPersonal").display = "none";}
    //alert(`my Name is ${result.firstName}  ${result.lastName}`);






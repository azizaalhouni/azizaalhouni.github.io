window.onload = function () {
    document.getElementById("signUp").onclick = addUser;
    document.getElementById("name").onselect = checkUser;
}
function checkUser(){
    let userName = document.getElementById("name").value;
    fetch(`signupAjax?name=${userName}`)
        .then(resp=>resp.json())
        .then(data=>processData(data));
}
function addUser(){
let userName = document.getElementById("user_name").value;
let password = document.getElementById("password").value;
let user = {userName, password};

fetch("signupAjax", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(user)
})
    .then(resp => resp.json())
    .then(data => clickButton(data))
}
function processData(data) {
    let msgArea = document.getElementById("msg1");
    //msgArea.innerText = data;
    //msgArea.innerText = "Thank you " + data.userName +" for registering with us";
    if (data.type === 0) {
        //if (!data.unique) {
        msgArea.innerText = "Username already taken.";
        //} else {
        //  msgArea.innerText = "New userName unique";
        //}
    }
    if (data.type === 1) {
        msgArea.innerText = "New userName";
    }
}

    function clickButton(data){
        let msgArea = document.getElementById("msg1");
        msgArea.innerText = "Thank you " + data.userName +" for registering with us";

}

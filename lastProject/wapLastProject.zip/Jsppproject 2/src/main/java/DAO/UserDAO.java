package DAO;

import model.UserInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDAO {

   public static Map <String, UserInfo> userDb = new HashMap<>();
   public static Map<String, UserInfo> adminDb = new HashMap<>();

     {
       // userDb.put("smith", new UserInfo("John","LastName","smith","123"));
        // userDb.put("user", new UserInfo("John","LastName","user","123"));
         userDb.put("smith", new UserInfo("smith","123"));
         userDb.put("user", new UserInfo("user","123"));
    }
   {
       adminDb.put("admin", new UserInfo("admin","1234"));
   }
    public void addAdminInfo(UserInfo adminInfo){
        userDb.put(adminInfo.getUserName(), adminInfo);
    }
    public List<UserInfo> getAllAdmins(){
        return new ArrayList<>(adminDb.values());
    }



    public static UserInfo addUserInfo(UserInfo userInfo){ return userDb.put(userInfo.getUserName(), userInfo); }
    public List<UserInfo> getAllUsers(){
        return new ArrayList<>(userDb.values());
    }
   // public String getUserName(){return userDb.getUsername();}
    public static boolean isUsernameTaken(String userName){
        return  userDb.containsKey(userName);
    }


}


package Controller;

import DAO.ProductDAO;
import com.google.gson.Gson;
import model.Product;
import model.UserInfo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(urlPatterns = {"/checkout.jsp","/order.jsp"})
public class CheckoutController extends HttpServlet {

    private ProductDAO dao;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        dao = ProductDAO.getDAO();
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

     /// Checkout Button

            PrintWriter out = response.getWriter();
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/checkout.jsp");
            view.forward(request, response);


    }
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //orderButton
       String userName= request.getParameter("firstname");
        HttpSession session = request.getSession();

       session.setAttribute("user",userName);
        System.out.println(userName);
       PrintWriter out = response.getWriter();
       RequestDispatcher view = request.getRequestDispatcher("WEB-INF/order.jsp");
        view.forward(request,response);
    }
}

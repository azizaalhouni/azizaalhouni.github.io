package Controller;

import DAO.ProductDAO;
import DAO.UserDAO;
import com.google.gson.Gson;
import model.Product;
import model.UserInfo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/admin")
public class LoginController extends HttpServlet{

    private ProductDAO dao=ProductDAO.getDAO();
    Gson mapper = new Gson();

        @Override
        public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            System.out.println("doget in login");
            String userr=request.getParameter("user_name");
            String pass= request.getParameter("pass");
            HttpSession session = request.getSession();
            //UserInfo user = UserDAO.adminDb.get(userr);
            System.out.println(userr+""+pass);
            //if(user!=null){
            if(userr.equals("admin")&&pass.equals("1234")){
                session.setAttribute("user",userr);
                request.setAttribute("products", dao.getAllProducts());
                RequestDispatcher req=request.getRequestDispatcher("WEB-INF/AdminPanel.jsp");
                req.forward(request,response);
            }
            else{
                session.setAttribute("err_msg", "Username and/or password invalid.");
               // response.sendRedirect("log");
                response.sendRedirect("admin.jsp");
            }

        }

        public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
            HttpSession session = request.getSession();
            //String userr=request.getParameter("user_name");
            //session.setAttribute("user",userr);
            //response.sendRedirect("product.jsp");

        }
}

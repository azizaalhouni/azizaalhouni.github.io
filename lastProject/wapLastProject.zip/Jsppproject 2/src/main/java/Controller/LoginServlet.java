package Controller;

//import dao.ProductDAO;
import DAO.UserDAO;
//import model.User;
import model.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDAO dao;
    @Override
    public void init() throws ServletException {
        dao = new UserDAO();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
      String userName = req.getParameter("user_name");
      UserInfo user = UserDAO.userDb.get(userName);
      if(user!= null){
          resp.getWriter().print("{\"msg\": \"hello\"} ");
      }
        if(session != null){
            req.setAttribute("err_msg", session.getAttribute("err_msg"));
            session.invalidate();//server cant identify the client which has visited in
            // previous.So now it creates a new session id for that client.
        }
        req.getRequestDispatcher("login.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("user_name");
        String remember = req.getParameter("remember");
        UserInfo user = UserDAO.userDb.get(userName);
        HttpSession session = req.getSession();

        if (user!=null && user.getPassword().equals(req.getParameter("pass")) ) {

            session.setAttribute("user", user.getUserName());
            System.out.println(user.getUserName());
            //session.setAttribute("user", new User(userName, password));
            if ("yes".equals(remember)) {
                Cookie c = new Cookie("user", userName);
                c.setMaxAge(30 * 24 * 60 * 60);
                resp.addCookie(c);
            } else {
                Cookie c = new Cookie("user", null);
                c.setMaxAge(0);
                resp.addCookie(c);

            }
            resp.sendRedirect("welcome.jsp");
        } else {
            session.setAttribute("err_msg", "Username and/or password invalid.");
            resp.sendRedirect("login");
        }
    }

}



package Controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/jean.jsp")
public class ViewProduct extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher dispache= req.getRequestDispatcher("viewproduct.jsp");

        //String name="shoes";
        //req.setAttribute("product",name);
        dispache.forward(req,resp);
System.out.println("checki do get"+ req.getParameter("jeans"));
    }


}

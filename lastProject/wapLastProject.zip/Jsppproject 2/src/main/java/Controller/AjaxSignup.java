package Controller;

import DAO.UserDAO;
import com.google.gson.Gson;
import model.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/signupAjax")
public class AjaxSignup extends HttpServlet {
    Gson mapper = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("name");
        //System.out.println(userName);
        UserInfo user = UserDAO.userDb.get(userName);

        boolean isUsernametake = UserDAO.isUsernameTaken(userName);
        System.out.print(isUsernametake);

        if (isUsernametake) {
            System.out.print(isUsernametake);
           // PrintWriter out = resp.getWriter();
            resp.getWriter().print("{\"type\": 0,\"unique\":false}");
           // out.print("{\"msg\":\"you already have an account\"}");
            System.out.println("Already have an account");

        }
        else{
            resp.getWriter().print("{\"type\": 1, \"unique\":true}");
           // resp.getWriter().print("{\"type\":0,\"unique\": true");
            //PrintWriter out = resp.getWriter();
           // out.print("{\"msg\":\"I like your userName\"}");
            System.out.println(userName);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = req.getReader();

        try{
            String line;
            while ((line=reader.readLine()) !=null){
                sb.append(line).append('\n');
            }
        }finally {
            reader.close();
        }

        String user_json = sb.toString();
        UserInfo user= mapper.fromJson(user_json, UserInfo.class);
        UserDAO.addUserInfo(user);
        PrintWriter out = resp.getWriter();

        out.print(mapper.toJson(user));
    }
    }

